#include <stdio.h>
#include <stdlib.h>

#include "utilities.h"

#include "gmp.h"
#include "buffer.h"
#include "rsa.h"
#include "text_rsa.h"

#define DEBUG 0


int lengths(int *block_length, int *cipher_length, int *last_block_size,
	    buffer_t *msg, mpz_t N){
    int status = NOT_YET_IMPLEMENTED;
/* to be filled in */
    return status;
}


int RSA_text_encrypt(mpz_t *cipher, int block_length,
		     int cipher_length, int last_block_size,
		     buffer_t *msg, mpz_t N, mpz_t e){
    // cipher is a table of mpz_t of length cipher_length.
    // Memory allocation and initialisation of the cells is
    // already done.

    // block_length denotes the size of blocks of uchar's
    // which will partition the message.
    // last_block_size denotes the size of the last block. It may
    // be 0.
    int status = NOT_YET_IMPLEMENTED;

/* to be filled in */
    return status;
}

int RSA_text_decrypt(buffer_t *decrypted, mpz_t *cipher,
		     int cipher_length, int block_length,
		     int last_block_size,
		     mpz_t N, mpz_t d){

    int status = NOT_YET_IMPLEMENTED;
    // buffer decrypted is supposed to be initialised.
    buffer_reset(decrypted);
	
/* to be filled in */
    return status;
}
