void XGCD(mpz_t g, mpz_t u, mpz_t v, mpz_t a, mpz_t b);
void rational_reconstruction(mpz_t s, mpz_t t, mpz_t a, mpz_t m);
int linear_equation_mod(mpz_t x, mpz_t a, mpz_t b, mpz_t m);
